Login Details

Login Details for admin : admin/Deepak@123456
Login Details for Patient: ajay@gmail.com/Test@123
Login Details for Doctor: alok@gmail.com/Test@123

